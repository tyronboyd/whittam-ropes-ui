"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AppSettings = (function () {
    function AppSettings() {
    }
    return AppSettings;
}());
exports.AppSettings = AppSettings;
//# sourceMappingURL=config.js.map