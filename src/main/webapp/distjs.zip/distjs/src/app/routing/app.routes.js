"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var home_component_1 = require("../components/home.component");
exports.routes = [{
        path: 'home', component: home_component_1.HomeComponent, canActivate: [], children: []
    },
];
//# sourceMappingURL=app.routes.js.map